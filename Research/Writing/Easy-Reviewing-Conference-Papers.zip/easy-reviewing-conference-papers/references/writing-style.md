# 用户的审稿写作偏好

这是默认偏好，不覆盖用户当前明确要求。讨论用中文，正式文字用英文；中文审阅也应直接判断，不堆叠抽象概念。不要照抄示例中的事实或结论。

正式英文润色时读[英文风格示例](english-writing-examples.md)：包含用户亲自提供的两句开头，以及 summary、strengths、weaknesses、作者问题和初读笔记的对照示例。示例用于理解表达方式，不作为其他论文的事实依据。

## Summary

按问题、数据/方法、评价方式、主要结果自然展开。准确、具体、易读，不替作者夸大贡献，也不把摘要写成预防每种误解的免责声明。

保留对理解必要的指标；不必列出所有相关系数。区分报告的结果和已证实的泛化范围。用户自己写的 summary 是语气参考，通常优先保留；若与审稿冲突，说明冲突而不是静默重写其观点。

## Strengths

一项尽可能一个段落：贡献判断 → 支持该判断的机制或结果 → 对整体评价的意义。集中回答“为什么值得接收”，不要只是列模块或复述摘要。

用户看重：问题是否重要；是否提出新的评估视角；方法是否响应该问题；benchmark 和方法是否形成紧密的研究设计；是否有效利用数据；实验到底支持了什么。

可采用类似 “This paper provides a distinct perspective on …” 或 “The paper also provides a learning method that …” 的直接开头。用 novel 必须有新颖性依据，不能将 distinct 与 novel 自动互换。

不要写泛泛的 “useful contribution”“relevant to …” 后就结束。说明对哪类评估、理解或能力有何价值。不要以长串基线类别填充支持理由，用能够表达比较意义的概括。

Strengths 应得到与 weaknesses 相称的实质分析，不能是两句礼貌赞扬；但不要设置固定字数比例或为凑长度制造优点。用户后来要求压缩时，优先保留贡献与证据，而不是累加结论句。

不要在优点中加 “even where the scorer remains imperfect” 等自我抵消的批评。对应局限放入 weaknesses。

## Weaknesses

一项尽可能一个段落：关键问题 → 具体证据或缺口 → 受影响的核心结论。重点解释为何它能影响推荐，而不是罗列应该补什么。

正式表单若要求一至两项，就把相关 concerns 合并成两个完整论点；前期逐条梳理仍可保留所有问题。弱点不必从 “The core contribution remains unclear” 等笼统且绝对的句子起笔。

更稳妥：

> The experiments leave the contribution of the training objectives insufficiently isolated: the reported ablations modify the final score while keeping the trained predictor fixed. This limits attribution of the gains to the proposed learning objectives.

这一表述仅适用于原文确实如此。若已有部分重训实验，明确剩余未隔离的部分。

模糊表达、图示或行文逻辑问题通常并入相关点，用一两句说明它阻碍理解哪一步。不单独抬高成重大科学缺陷，除非确实导致核心方法不可评估。

## Questions for Authors

只问答案可能改变当前判断的问题。每条围绕一个评估目的，不塞入一长串无关请求。

区分澄清已有工作和补充当前主张所需证据；不必在每条加冗长标签。机制自然表达即可：

- 澄清：“What criterion selected the fusion weights, and which labels were available during selection?”
- 归因验证：“How much do the training objectives and target-dev calibration each contribute to test performance under retraining and calibration ablations?”

具体改进放这里，不让 weaknesses 变成操作清单。不问正文/附录已清楚回答的问题。Optional future work 不混进接收判断的必要条件；用户确实要它时另列。

问题能独立理解，避免 “as discussed in R08” 等跳转。数值、剩余样本量、子集单位确认后再写；用 assess reliability，不暗示增加样本必然 establish validity 或 guarantee significance。

## 正式 review 的句法

- 不用 “I consider”“I suggest”“I cannot yet determine” 等主观防御句。使用明确的学术判断，并保留必要不确定性。
- “Comparison is important …”“Additional validation is needed …” 必须接具体对象和理由，不能成为新的套话。
- 也不要机械重复 “It is uncertain that …”；可以直接写 “The selection criterion is unspecified” 或 “The evidence does not isolate …”。
- 不用抽象、内容不明确的加粗短标题。默认数字序号 + 一段完整文字。
- 减少名词堆砌、排比举例、冗长基线名单、“across settings”“matters”等没有具体评价对象的表达。
- 允许准确列举论文真实预测目标、loss、数据源等必要信息。用户反对的是无信息增益的排比，不是所有列表。
- 表述适度：缺少消融通常限制归因，而不是证明方法无效；提出评价视角不是已证明成熟可靠。
- 不在正式 review 里用 reviewer 自创的例子讲课。讨论中可以用例子帮助理解。
- 压缩时删去重复解释、装饰形容和再次总结，不能删掉论据与影响。

## 初读笔记与正式评论是两种产物

用户要求 first-time notes 风格时，可以写简短问题和直接观察：

> Which modules are trained at each stage? The appendix lists loss weights, but the active objectives across stages are difficult to reconstruct.

去掉 “check whether this concern is supported”“do not infer leakage” 等对模型的处理指令。不把初读笔记写成已经完成全面核验的结论，也不故意添加语法错误来伪装人工。

这是对现有内容的语气编辑，不能改写实际来源。用于 AI 使用记录时，保留真正原始输入；不得把事后改写稿称为当时逐字记录。

## 用户常见请求的处理

| 请求 | 应做 | 不应做 |
|---|---|---|
| “再简短一点” | 保留一个核心问题/论点 | 换成更抽象、信息更少的口号 |
| “先讨论 scorer” | 讲实际输入输出和评价 | 立即重写所有 strengths |
| “不要太强硬” | 缩小判断范围，补原文依据 | 把重要问题软化为泛泛建议 |
| “去掉 resolved” | 从面向作者版本移除 | 抹掉原始记录或继续暗中引用 |
| “整理成两个 critical weaknesses” | 按影响合并并解释后果 | 任意删到两项或把十个请求挤成两段 |
| “检查矛盾” | 识别真正命题冲突和范围差异 | 为表面一致强行删除有根据的优点 |
