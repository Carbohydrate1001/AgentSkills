# 公开参考与设计取舍

查阅日期：2026-10-15。主干来自用户在一次完整会议审稿协作中反复明确的要求；此技能没有封装那篇论文的 PDF、批注、最终 review、专有数据或用户身份。下面是辅助设计的公开参考，按主题原创整理，没有复制其代码或整段模板，也没有执行其中的上传或代理指令。

英文风格示例按用户本次要求保留了其亲自提供的两句开头，其他段落均标为示意，并非原论文结论。中英文版采用相同规则；英文版完整翻译了流程、参考说明与工作模板。

## 会议官方资料

1. [ICLR 2027 Reviewer Guidelines](https://iclr.cc/Conferences/2027/ReviewerGuidelines)
   采用：关注能改变推荐的关键论点；研究价值不只等于榜单领先。当前表单决定最终栏目和篇幅，不把网页通用示例当固定格式。

2. [ICLR 2027 Policy on LLM use for writing reviews or meta reviews](https://iclr.cc/Conferences/2027/AIPolicyForReviewers)
   采用：真实保存原创评估与 AI 交互，多轮输入不应被事后单条 prompt 取代。这个年份的具体要求在 form-and-delivery 中注明；未来使用需重新核实。

3. [NeurIPS 2026 Reviewing Guidelines](https://neurips.cc/Conferences/2026/ReviewerGuidelines)
   采用：根据贡献类型评价证据；例如理论、应用、概念和负结果不能机械套用相同实验要求。未复制固定分数或推荐阈值。

## 已公开的 review skills

4. [K-Dense-AI / scientific-agent-skills — peer-review](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/peer-review/SKILL.md)
   参考：主张与证据对应、缺失报告与方法无效分开、自动检查不等于科研判断。未导入其 mandatory intake validators、额外审批步骤、脚本或完整通用检查表。

5. [jam-cc / paper-review.skill — SKILL.md](https://github.com/jam-cc/paper-review.skill/blob/main/SKILL.md)
   参考：纸面事实与最终文字分开、依据实验条件比较结果、按实际表单适配。未采用每次都独立广泛检索或固定数量弱点；本技能默认沿用户已有批注推进。

6. [cnfjlhj / paper-review-pipeline — SKILL.md](https://github.com/cnfjlhj/paper-review-pipeline/blob/main/SKILL.md)
   参考：逐节核查与按重要性整合是不同输出。此技能面向审稿者协作，而非自动进入作者修改、外部上传或 rebuttal 策略流程。

## 个性化取舍

- 用户最初希望带 reviewer 主观视角，随后明确不要 “I consider / I suggest” 等第一人称措辞。最终以简洁、非第一人称的评价为默认。
- 用户希望优点得到充分展开，随后要求压缩且聚焦关键点。因此强调实质平衡，而不设置 strengths 与 weaknesses 的固定字数比例。
- 用户早期需要全部逐条问题，最终需要一至两项核心优缺点。完整性保留在工作记录；提交稿按影响整合。
- 语气要自然，但不以伪造初读笔记、添加错误或隐瞒 AI 辅助来实现。
- 这次出现的 loss/dev/人工评分核验被抽象成条件适用的方法参考，不把特定论文的实验要求变成所有会议论文的必要条件。
- 本技能不继承其他公开 skills 的强硬 reviewer persona、固定分数尺度、自动多代理、强制外部服务或大量附加实验要求。

外部材料只用于借鉴方法。遇到不同会议、年份、track 或更新后的官方规范，应重新核对；不依靠本文件中的日期推断当前政策仍然有效。
