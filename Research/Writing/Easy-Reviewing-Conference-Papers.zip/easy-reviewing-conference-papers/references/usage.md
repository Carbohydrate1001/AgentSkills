# 使用示例

压缩包中的 `easy-reviewing-conference-papers/` 是完整技能目录，入口为 `SKILL.md`。在支持技能目录的环境中导入或放入其配置的 skills 目录；也可以直接把 `SKILL.md` 与所需参考文件提供给助手。不同客户端的安装位置以其实际配置为准。

显示名称：Easy-Reviewing-Conference-Papers。标准技能标识：`easy-reviewing-conference-papers`。

中英合集中，`SKILL.md` 是中文入口，[SKILL.en.md](../SKILL.en.md) 是完整英文入口，另附英文参考文件和 metadata。独立英文压缩包已经将英文入口与 metadata 放到标准的 `SKILL.md` 和 `agents/openai.yaml` 位置，可直接按客户端方式导入。两版采用同一个技能标识，安装时选择一版，避免同名重复注册。

两版共用[英文风格示例](english-writing-examples.md)，含用户提供的开头和明确标注的示意改写；无需同时加载两套语言说明。

## 开始核验批注

> 使用 $easy-reviewing-conference-papers。我们正在审阅一篇会议论文。请先核验我在 PDF 中的批注和下面补充的观点，结合正文和附录纠正理解，不要独立扩展新的审稿议题。中文讨论，保留原始批注，并给出英文 R01、R02… 逐条意见。

## 先讲清楚方法

> 先不要改 review。请从输入、训练目标、推断输出、校准和最终评估解释这个方法。说明结果表每组实验比较什么；必要时只用一个假设例子。然后再讨论它对我们 strengths/weaknesses 的影响。

## 压缩成正式 review

> 基于已经核验的观点，按我提供的表单整理一至两项 Critical Strengths 和一至两项 Critical Weaknesses，每项一个段落。说明为何影响评价。具体澄清与实验请求放入 Questions for Authors，避免抽象加粗标题、第一人称防御句和冗长列举。不要改变已认可的 summary。

## 最终检查

> 检查这份实际填写的 review，重点找 summary、strengths、weaknesses、作者问题和评分之间的矛盾。分别列出必要更正和可选措辞改善；不要提交。

## AI 使用记录

> 按顺序汇集本次实际可见的用户输入和原始批注，原样保留，标明来源和缺失部分。不要把整理稿伪装成最初输入，也不要替我撰写要求由人类原创的评估。

这套技能不预设论文的接收或拒绝结论，也不预设所有问题最终都应保留。它不会仅因为使用了 dev、报告中等相关或没有全量人工审核，就自动给出负面判断。
