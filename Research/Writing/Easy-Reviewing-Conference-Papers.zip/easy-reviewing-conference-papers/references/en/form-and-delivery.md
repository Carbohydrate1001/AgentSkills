# Forms, AI records, scoring, and delivery

## Use the current form

Read the supplied review form or the relevant year's official guidance before mapping fields and scores. Do not hard-code an ICLR 1–4 scale, a generic skill's 1–10 scale, or an older NeurIPS scale. Contribution type, track, and year may change the assessment criteria.

Fill the whole form only when the user requests a complete draft. Preserve requested blank fields in a working draft; do not insert “None” as a fabricated human declaration. If the venue requires an AI disclosure, identify the remaining submission requirement without writing the required human-original assessment for the reviewer.

Recommend scores only when asked. Use the actual labels and definitions, explain which concerns determine the recommendation, and identify what evidence could change it. Do not convert the number of weaknesses into a score. Distinguish unsupported but fixable claims, fundamental errors, and readability problems. Confidence depends on the reviewer's experience, not on the length or certainty of the assistant's analysis.

## Cross-field consistency

Before final delivery, check:

1. **Summary versus weaknesses:** Does the summary assert validated reliability, fully unsupervised scoring, or strict OOD evaluation that the weaknesses question? A factual description of a design does not necessarily endorse its adequacy.
2. **Strengths versus weaknesses:** A valuable evaluation perspective can coexist with incomplete human validation; relative gains with modest absolute correlation; informative readout ablations with missing retrained ablations. These are not automatically contradictions.
3. **Questions versus available evidence:** Verify counts, denominators, evaluator roles, references, and experimental scope. Remove questions answered in the manuscript or identify the real remaining ambiguity.
4. **Significance versus magnitude:** Qualify statistically significant gains as applying to some comparisons when appropriate. Do not treat small gains as worthless or moderate correlation as a statistical error.
5. **Clarification versus validation:** Does revised wording fix reporting alone, or also answer the methodological concern? Are full-corpus or multi-rater requests proportionate to the claim and the user's focus?
6. **Scores versus prose:** Weak rejection can coexist with substantive strengths. A lowest soundness category defined by difficult-to-repair flaws may conflict with prose describing only fixable gaps.
7. **Versions:** Check the actual final artifact and user edits, not an earlier template. Ensure HTML, PDF, form text, and scores agree where they should.
8. **Residue:** Remove unfilled author-facing placeholders, stray entities, broken Markdown, obsolete cross-references, editing instructions, internal notes, and accidental blank pages.

Separate required factual corrections or genuine contradictions from optional wording improvements. Say plainly when there is no contradiction. If scores are absent, do not claim to have checked them.

## Preserve actual inputs for AI documentation

Keep the reviewer's original assessment, verified facts, AI assistance, and final judgment distinguishable. Documentation should be assembled from existing records, not from a newly invented “initial prompt.”

Appropriate assistance includes:

- Collecting actual visible user inputs and original annotations verbatim, with order and provenance. Do not relabel model replies as user input.
- Identifying missing turns or materials and the limits of available history.
- Organizing a factual description of assistance, such as explanation, verification, drafting, and editing, for user confirmation.
- Creating a new reusable prompt, clearly treated as a new prompt rather than a historical record.

Do not label an AI-edited R-list as human-written original notes, describe iterative drafting as spelling correction alone, reconstruct an allegedly complete verbatim log from memory, or confuse a first-reading-note style edit with when the text was written.

The [ICLR 2027 AI policy](https://iclr.cc/Conferences/2027/AIPolicyForReviewers), consulted on 2026-10-15, requires disclosure, the original self-written assessment, and AI interactions. Its FAQ asks for inputs across all turns of iterative polishing, and the policy prohibits using AI to populate the initial self-report. Verbatim archiving can support compliance; generating the required human-original assessment cannot. Recheck other years and venues instead of treating this as a universal policy.

A set of edited excerpts is not necessarily a complete interaction record. Identify the specific gap without adding unrelated warnings.

## Files and visible forms

- When asked to edit the same HTML, update that file and keep a necessary pre-edit backup. Do not create competing drafts each turn.
- Separate original annotations and working records from author-facing prose without fragmenting a single argument across files.
- If delivering Chinese and English comments, preserve the same R IDs and judgments rather than creating independently evolving reviews.
- Use real export tools. Inspect every PDF page for fonts, pagination, tables, links, clipping, and blank pages; render Word when tools permit. State unverified layout limits rather than claiming an inspection that did not happen.
- Package only requested deliverables. Exclude source manuscripts, private annotations, browser data, cached logs, and machine-specific paths from a reusable skill ZIP.
- Read the actual filled values when checking a web form. Do not infer them from an old local draft. If access fails, state the limitation and use the user's pasted or exported text.
- Inspection is not submission. Send or submit only when explicitly requested, subject to the host tool's requirements.
