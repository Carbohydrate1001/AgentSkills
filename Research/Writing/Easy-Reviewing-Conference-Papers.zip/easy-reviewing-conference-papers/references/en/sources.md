# Public references and design choices

Sources consulted: 2026-10-15. The primary design comes from the user's requirements developed during a complete conference-review collaboration. The package excludes the original manuscript, private annotations, final review, proprietary data, and user identity. The two short user-supplied opening sentences in the writing examples are included as requested style anchors. Other examples are synthetic.

The following public materials informed the design. Their code and full templates were not copied, and their upload or agent instructions were not executed.

## Official conference materials

1. [ICLR 2027 Reviewer Guidelines](https://iclr.cc/Conferences/2027/ReviewerGuidelines)
   Adopted: concentrate on considerations that can change the recommendation; value is not limited to leaderboard superiority. The actual form determines final fields and length.

2. [ICLR 2027 Policy on LLM use for writing reviews or meta reviews](https://iclr.cc/Conferences/2027/AIPolicyForReviewers)
   Adopted: preserve original human assessment and real interactions; do not substitute a retrospective single prompt for multi-turn input. Recheck the policy for subsequent use.

3. [NeurIPS 2026 Reviewing Guidelines](https://neurips.cc/Conferences/2026/ReviewerGuidelines)
   Adopted: assess evidence according to contribution type rather than imposing identical experiments on theory, applications, concepts, and negative results. No fixed score scale was copied.

## Public review skills

4. [K-Dense-AI / scientific-agent-skills — peer-review](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/peer-review/SKILL.md)
   Informed claim-to-evidence checking and the distinction between reporting gaps and invalid methods. Its mandatory intake validators, approval workflow, scripts, and extensive general checklist were not imported.

5. [jam-cc / paper-review.skill — SKILL.md](https://github.com/jam-cc/paper-review.skill/blob/main/SKILL.md)
   Informed separation of evidence notes from final prose, protocol-aware result comparisons, and adaptation to the supplied form. Broad independent searches and fixed weakness counts are not defaults here.

6. [cnfjlhj / paper-review-pipeline — SKILL.md](https://github.com/cnfjlhj/paper-review-pipeline/blob/main/SKILL.md)
   Informed the separation of section-level investigation from prioritized synthesis. This skill assists a reviewer rather than automatically starting an author-revision, external-upload, or rebuttal workflow.

## Personalization decisions

- The user's later preference for direct impersonal prose supersedes earlier requests for first-person perspective.
- Strengths receive substantive analysis, while later requests for compression rule out a fixed strengths-to-weaknesses word-count ratio.
- Full issue coverage belongs in the working record; final critical points are consolidated by their effect on the assessment.
- Natural prose does not require fabricated first-reading notes, deliberate errors, or concealed assistance.
- Loss, dev, and human-rating checks from the collaboration became conditional reference guidance, not requirements for all papers.
- No harsh-reviewer persona, fixed scoring scale, automatic delegation, external review service, or indiscriminate demand for extra experiments is inherited from other skills.
- Chinese and English editions apply the same rules and judgments. English examples make the user's style concrete without converting sample claims into reusable findings.

These materials inform procedure, not the verdict on a new manuscript. Recheck changing venue, year, track, or policy requirements rather than assuming this dated record remains current.
