# Usage examples

The archive contains a complete `easy-reviewing-conference-papers/` skill directory. Use the host's supported skill-import mechanism or configured skills directory. Alternatively, supply the entry point and relevant reference files to an assistant that can read Markdown. Installation locations depend on the host.

Display name: Easy-Reviewing-Conference-Papers. Skill identifier: `easy-reviewing-conference-papers`.

The bilingual archive keeps the Chinese entry point as `SKILL.md` and the English equivalent as `SKILL.en.md`. It also contains English references and metadata. The separate English archive already uses the English entry point as `SKILL.md` and English UI metadata as `agents/openai.yaml`. Both editions represent the same skill; install one rather than registering duplicate copies under the same ID.

The English writing examples are shared by both editions. They preserve the user's preferred English style without requiring both instruction sets to be loaded.

## Audit existing notes

> Use $easy-reviewing-conference-papers. We are reviewing a conference paper. Verify my PDF annotations and the concerns below against the main text and appendices. Correct misunderstandings rather than expanding into an unrelated review. Preserve my original notes and produce numbered English comments using R01, R02, and so on.

## Explain the method first

> Do not revise the review yet. Explain the method through its inputs, training objectives, direct outputs, calibration, and final evaluation. Clarify what each group in the results table compares, using one hypothetical example if needed. Then discuss the implications for our strengths and weaknesses.

## Produce concise submission prose

> Using the verified concerns and the supplied form, write one or two Critical Strengths and one or two Critical Weaknesses, one paragraph per point. Explain why each affects the assessment. Put concrete clarification and validation requests in Questions for Authors. Avoid abstract bold mini-headings, defensive first-person phrasing, and long lists. Preserve the accepted summary.

## Check the completed review

> Check the actual review text for contradictions across the summary, strengths, weaknesses, author questions, and scores. Distinguish necessary corrections from optional wording changes. Do not submit the review.

## Preserve AI-use records

> Collect the actual visible user inputs and original annotations in order, without rewriting them. Identify sources and missing history. Do not replace the original inputs with a reconstructed prompt or write an assessment that the form requires to be human-original.

This skill does not predetermine acceptance or rejection. It does not treat dev use, moderate correlation, or incomplete audit coverage as automatic grounds for a negative judgment.
