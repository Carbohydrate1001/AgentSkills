# Auditing annotations and numbered concerns

Use for annotated PDFs, reading notes, and additional section-level comments. Refer to the current paper's actual sections. The checks below are conditional tools, not a ready-made list of faults for every paper.

## Preserve the original layer

- Retain the user's exact text, including tentative judgments, questions, fragments, and later corrections. Keep translations, tone edits, and consolidation separate from originals.
- Inspect PDF `/FreeText`, `/Text`, comments attached to highlights, and replies. `/Link` objects are not reviewer comments. `/Popup` may be a display container for the same comment; avoid double counting.
- Distinguish all PDF annotation objects, actual reviewer comments, highlight-only regions, and issues after splitting compound comments. A citation-link count is not a reviewer-annotation count.
- Retain text, page, source/object ID, and position where available. For highlights without comments, retain the selected passage without inventing an objection.
- Check complex text boxes, handwriting, reading-order problems, tables, and equations against rendered pages. Identify inaccessible or unreadable material.
- Split independent concerns within one annotation while preserving their common source. Short or duplicate notes still need a disposition.

## Stable IDs without burdening the reader

Preserve existing source IDs; otherwise assign them in page and reading order. Use R01, R02, and subsequent IDs for user-facing comments.

Merging does not erase provenance. Dropping a criticism from the final review does not erase the annotation. Append, merge, or explicitly retire IDs rather than silently assigning an old ID to a different issue.

## Investigate each concern

Record internally:

1. The user's concern and the precise claim challenged.
2. The answer available in the main text, appendices, tables, or equations.
3. Supporting and opposing evidence, distinguishing facts, deductions, and unknowns.
4. The strongest reasonable author response and whether it resolves the concern.
5. The conclusion or contribution affected by the remaining issue.
6. The smallest clarification or controlled comparison that could change the assessment.

Possible working labels are VALID, PARTIALLY VALID, RESOLVED, NOT SUPPORTED, UNRESOLVED, and CONDITIONAL. They are not a scoring algorithm. An unanswered question is not automatically major, and forceful wording is not stronger evidence.

For a clean numbered draft, retain only material surviving concerns and give direct references such as “Section 3.2; Appendix C.” Avoid a repeated display scaffold of “evidence location / underlying concern / potential rebuttal / refinement.” Keep detailed investigation in the workbook.

## Scope and severity

- Missing literature support for a taxonomy does not imply that every possible category must be covered. Check the authors' actual coverage claim before challenging completeness.
- An extreme hypothetical offered by the user to explain a concern is not an allegation about the actual dataset.
- A reading difficulty is not evidence of an error. Explain the method first; narrow or drop the concern when the paper supplies the answer.
- Consistent wording may resolve a reporting contradiction without supplying the missing empirical validation.
- Future work cannot replace evidence needed for a present central claim. However, reasonable scope limits and every unperformed extension are not grounds for rejection.
- For novelty, compare objectives, inputs, supervision, and outputs of the nearest predecessors, not just terminology. Do not fault authors for omitting work published after their submission cutoff.

## Literature verification

Search to address the current concern. Retain the title, year, direct source, and the exact proposition a reference supports. Do not turn a common practice or an adjacent-domain paper into an established consensus.

For claims about rating rubrics, specify the task and evidence. A rubric does not guarantee accuracy, and missing intermediate anchors do not imply that no instructions were given.

## Iteration

When the user asks to proceed step by step, resolve the current concept or paragraph without replacing the discussion with a full review. Apply corrections to the corresponding record and any affected review sections. Leave accepted passages unchanged when no relevant issue arises.
