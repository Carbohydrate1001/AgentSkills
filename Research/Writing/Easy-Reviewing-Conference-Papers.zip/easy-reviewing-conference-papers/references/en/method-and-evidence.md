# Methods, data, and empirical evidence

Select checks according to the contribution type and the user's concerns. They support explanation and judgment; they are not demands for every possible experiment. Do not penalize a theory paper for irrelevant engineering ablations or require a dataset paper to invent a model.

## Connect the paper's contributions

Explain the problem, what the data and method each address, how they jointly test the main claim, and what the results establish. Listing modules is not an analysis of the paper's coherence.

| Layer | Question to answer |
|---|---|
| Materials | What data, labels, or participant instructions supply the inputs? |
| Training | What are the target variables, losses, teachers, and trainable modules? |
| Inference | Does the model directly produce distributions, labels, scalars, or generated content? |
| Score construction | How are outputs aggregated, normalized, and combined? |
| External evaluation | What independent labels or human judgments evaluate the resulting score? |
| Claim | Which result supports which contribution, and which explanations remain unisolated? |

Do not confuse a scorer's output with the metric used to evaluate it, or a training target with a final human rating.

## Explain concretely

First answer what a step does, then provide the necessary equation, and finally its implication for the review. Use one hypothetical example if needed, explicitly labeling its numbers as illustrative. Examples belong in discussion, not automatically in submission prose.

If the user remains confused, identify the unresolved object: the denominator of accuracy, the label determining the ordering, or the samples supplying dev statistics. Avoid repeating abstractions such as “learns appropriateness.”

## Separate training from calibration

Map each data source to gradient training, target extraction, normalization, fusion-weight selection, hyperparameter/model/checkpoint selection, and final reporting. Record the labels available at each step.

- No human-rating supervision for neural training does not imply no human supervision anywhere in the scoring procedure.
- Selecting settings on dev and fixing them for test is an ordinary evaluation design. The presence of dev does not establish leakage.
- Identify a concrete path by which test information influences choices before alleging test leakage.
- Source training with target-dev calibration and target-test evaluation differs from using no target data. Speaker/session separation alone does not establish strict out-of-domain evaluation.
- A speaker-separation claim, aggregate counts, and a verifiable mapping are different evidence levels. Request anonymized counts or mappings rather than real identities.
- A hyperparameter table may still leave stages unclear. Ask for missing stage × trainable module × active loss information, duration, or checkpoint criteria without claiming that no training details exist.

For z-scores, the mean and variance define a reference scale, not a human gold standard or guaranteed domain alignment. Applying the same positive affine transformation to a set of scores preserves its ranking and Spearman correlation. Combining separately standardized components can change their relative contributions and the final ranking. Do not extend within-group invariance to pooled groups transformed differently.

## Decode results before interpreting them

For each main comparison, identify the split, sample or pairing unit, metric definition and direction, comparator, and uncertainty. A compact reorganized table can help, provided the original values and locations remain traceable.

- Pairwise ranking accuracy is not individual classification accuracy. Ranking by condition labels is not necessarily ranking by human judgments.
- Correlation is not accuracy, explained variance, or causality. A moderate correlation is not itself a statistical error.
- Distinguish numerical improvement, statistical significance, and practical value. Do not extend a significance marker to the whole table or overlook appendix bootstrap results and intervals.
- Compute differences within the same subset, split, rating column, and comparator. Do not mix differences from separate experiments or describe a correlation gain as percentage-point accuracy.
- Scorers with different raw scales can be compared against a common external criterion. Check adaptations, inputs, and calibration resources when defining the scope of that comparison.
- Repeated speakers, sessions, or raters may require clustered or hierarchical analysis. Do not assume every observation is independent.
- Inter-rater correlation is not automatically a ceiling for model performance without the relevant reliability assumptions.

## Match ablations to attribution questions

| Intervention | What it primarily assesses | What it does not directly isolate |
|---|---|---|
| Remove a score component from a fixed predictor | The final readout's composition | The learning contribution of its loss |
| Remove a loss and retrain under a controlled protocol | That training objective's contribution | An independent effect if data or compute also change |
| Change windows or discretization and retrain | Sensitivity to temporal design | That finer resolution must be better |
| Calibrate on independent source data and evaluate the same target test | Dependence on target-dev calibration | Normalization and fusion contributions separately |

The readout is part of the method. Do not claim there are no method ablations merely because only score components are removed. Identify the missing retraining or calibration comparison precisely.

A no-target-dev condition must not reuse weights, models, or checkpoints selected with target dev. Separate attribution to normalization and fusion requires separate controls; a joint no-dev comparison answers overall calibration dependence. Do not conflate these questions.

## Human ratings, manipulations, and benchmarks

- Separate an instructed behavior or emotion from its perceptible realization. If the construct concerns expression quality, do not turn it into a requirement to measure private emotion or physiology.
- Examine screening, failed or ambiguous enactments, event occurrence, frequency/intensity, and unintended artifacts. Missing statistics do not prove a particular confound occurred.
- Participants, supervisors, and independent listeners are distinct roles. Including all three in an ICC does not create three independent evaluators.
- Audit coverage and independent evaluators per conversation are separate issues. Extending coverage does not resolve single-listener validation of the original audited subset.
- Preserve a user's justified request for a full audit without making full-corpus annotation a universal prerequisite for reliability estimation. Consider sampling, representativeness, precision, raters, and the claim.
- Multiple evaluators do not guarantee significance or eliminate bias. Call the intended check inter-rater reproducibility rather than ambiguously implying machine-learning K-fold cross-validation.
- For delay, equipment, and alignment, distinguish interaction characteristics from measurement-path effects. A separate latency probe does not supply per-session offsets or establish a significant effect on ratings.
