# The reviewer's writing preferences

These are defaults, not overrides of a new explicit request. Follow the conversation's language and use English for submission prose. The user's own summary is the preferred style reference. For concrete models, read the [English writing examples](../english-writing-examples.md); never import their claims into a new review without evidence.

## Summary

Explain the problem, data or method, evaluation, and main results in connected prose. Be accurate and specific without overstating the authors' contribution or defensively qualifying every sentence.

Include numbers when they clarify the finding; do not enumerate every metric. Separate reported performance from established generalization. Preserve an accepted user-written summary and flag a factual conflict rather than silently changing the reviewer's position.

## Strengths

Use one paragraph per point where possible: a contribution judgment, supporting mechanism or result, and its consequence for the overall assessment. Explain why the work merits acceptance instead of listing components or repeating the summary.

The user values the importance of the question, a distinctive evaluation perspective, a method that addresses that question, a coherent relationship between benchmark and method, efficient use of data, and what the experiments actually establish.

Direct openings such as “This paper provides a distinct perspective on …” or “The paper also provides a learning method that …” fit the preferred style. Use “novel” only when the novelty assessment supports it; “distinct” and “novel” are not interchangeable.

Do not stop at “useful contribution” or “relevant to.” State what the contribution enables or advances. Replace long lists of baseline families with a concise explanation of what the comparison tests.

Give strengths substantive consideration comparable to weaknesses, not courtesy praise. Do not enforce a word-count ratio or invent positives. When shortening, retain the contribution and its evidence rather than accumulating concluding sentences.

Do not insert self-canceling qualifications such as “even where the scorer remains imperfect.” Discuss the limitation under weaknesses.

## Weaknesses

Use one paragraph per point where possible: the material issue, specific evidence or missing support, and the affected central conclusion. Explain why it matters to the recommendation, rather than enumerating desired revisions.

If the form requests one or two critical weaknesses, merge related concerns into complete arguments. Keep a fuller inventory in the working record. Avoid absolute openings such as “The core contribution remains unclear” when the actual issue is that particular gains are not isolated.

For a hypothetical paper whose reported ablations change only the readout:

> The experiments leave the contribution of the training objectives insufficiently isolated: the reported ablations modify the final score while keeping the trained predictor fixed. This limits attribution of the gains to the proposed learning objectives.

If the paper already includes some retraining, identify the specific contribution still unisolated. Do not reuse the example as a blanket criticism.

Integrate writing or figure problems briefly into the substantive concern they obstruct. Make them a major point only when the consequences genuinely prevent assessment.

## Questions for Authors

Ask questions whose answers could materially change the current assessment. Give each a clear purpose rather than a long inventory of unrelated requests.

Distinguish clarification of existing work from additional evidence for present claims. The distinction can be expressed through the question itself; lengthy repeated labels are unnecessary.

- Clarification: “What criterion selected the fusion weights, and which labels were available during selection?”
- Attribution: “How much do the training objectives and target-dev calibration each contribute to test performance under retraining and calibration ablations?”

Place concrete requests here, not as the entire content of a weakness. Do not ask what the paper already answers. Keep optional future work separate from evidence necessary for the current assessment.

Each question should stand alone without “as discussed in R08.” Verify counts, denominators, and audit coverage. Use “assess reliability” without suggesting that more data necessarily establish validity or guarantee significance.

## Sentence-level choices

- Avoid “I consider,” “I suggest,” and “I cannot yet determine” in formal review text. State the judgment directly and retain uncertainty where the evidence requires it.
- “Comparison is important” and “Additional validation is needed” must identify the comparison or validation and its purpose; they are not substitutes for reasoning.
- Do not mechanically repeat “It is uncertain that.” “The selection criterion is unspecified” often conveys the exact issue more clearly.
- Use numbered paragraphs without abstract bold mini-headings by default.
- Reduce noun piles, illustrative lists, long baseline inventories, and vague endings such as “across settings” or “this matters.”
- Preserve necessary lists of actual prediction targets, losses, or datasets. The objection is to lists with little information gain, not all enumeration.
- Missing ablations usually limit attribution; they do not prove that a method fails. Proposing an evaluation perspective is not equivalent to establishing a mature reliable metric.
- Use reviewer-created examples for explanation, not to teach the paper inside the formal review.
- Shorten by removing repeated reasoning, decorative adjectives, and repeated conclusions. Keep evidence and implications.

## Reading notes are a separate deliverable

When asked for first-reading-note style, use brief questions and direct observations:

> Which modules are trained at each stage? The appendix lists loss weights, but the active objectives across stages are difficult to reconstruct.

Remove instructions to the assistant such as “check whether this concern is supported.” Do not present tentative notes as a completed audit or introduce errors to imitate human writing. This is a tone edit, not a change of provenance. For AI documentation, preserve the actual original inputs.

## Common editing requests

| Request | Do | Avoid |
|---|---|---|
| Shorten it | Retain one clear issue or argument | Replace details with a vague slogan |
| Discuss the scorer first | Explain its computation and evaluation | Rewrite all strengths immediately |
| Moderate the wording | Narrow the claim and support it | Turn a material concern into generic advice |
| Remove resolved points | Remove them from author-facing text | Erase the original record |
| Produce two critical weaknesses | Merge by consequence for the assessment | Pack ten demands into two paragraphs |
| Check contradictions | Compare claims and their scopes | Remove a justified strength for superficial consistency |
