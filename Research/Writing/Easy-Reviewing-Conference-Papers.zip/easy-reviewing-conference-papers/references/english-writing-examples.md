# English writing examples

Use these examples to match the reviewer's reasoning and sentence style, not as a phrase bank. Except for the two user-supplied opening sentences identified below, the passages are synthetic examples. They do not describe a verified paper, dataset, result, or reviewer history. Check every substantive statement against the current manuscript before using it.

## 1. The user's own style anchors

The user supplied these two openings while discussing the preferred style:

> This paper provides a novel view of evaluating conversational naturalness through examining both disruptions and alignment with human judgements.

> The paper also provides a learning method that explicitly involves temporal coordination and affective alignment.

Preserve what these sentences do: identify the contribution early, name the actual research objects, and make a direct assessment. Do not force the same opening onto every paragraph. Use “novel” only when supported by the literature comparison; otherwise a more limited term such as “distinct” may fit.

These opening sentences alone are not complete strengths. Each needs brief support and an explanation of its consequence for the assessment.

## 2. Summary: connected description without defensive framing

For a hypothetical conversation-evaluation paper:

> This paper studies the evaluation of multi-turn spoken dialogue, focusing on temporal coordination and affective responses. It introduces a benchmark combining controlled human conversations with open-ended human–AI interactions. Human ratings are used to assess both the effects of prescribed disruptions and variation in perceived conversational quality.
>
> The authors also propose a context-conditioned predictor trained on natural dialogue with automatically extracted targets. Its outputs are combined into conversational scores, with normalization and fusion settings selected on development data. Evaluation examines discrimination between recording conditions and correlation with human ratings on held-out conversations.

The sequence is problem, data, method, and evaluation. Add the principal finding when verified. Do not force every concern from the weaknesses into this summary, and do not add a list of metrics unless it improves understanding.

## 3. Strength: evaluate the design, rather than offer generic praise

Less suitable:

> The benchmark makes a useful contribution and provides a practical basis for naturalness evaluation across settings. This matters because different metrics capture different things.

Preferred, if supported:

> This paper provides a distinct perspective on evaluating conversational naturalness by examining both disruptions and alignment with human judgements. The combination of controlled and open-ended conversations separates sensitivity to prescribed behaviours from agreement with perceived interaction quality. This gives the benchmark a clear role in evaluating what an automatic naturalness score actually measures.

The revised paragraph identifies a contribution, explains the design, and states its value. It does not simply replace “useful” with a stronger adjective.

## 4. Strength: connect learning to the problem

Less suitable:

> The same pause, overlap, or affective response may be appropriate in one context and awkward in another. This makes context-conditioned evaluation particularly relevant to spoken dialogue.

Preferred:

> The paper also provides a learning method that explicitly incorporates temporal coordination and affective alignment. Conditioning the prediction on preceding dialogue addresses the context dependence of conversational appropriateness. Learning from automatically extracted targets allows large conversational corpora to support the model, while a smaller human-rated set provides calibration and evaluation.

Where supported, add one sentence about the principal result and its significance. Do not imply that small-set calibration has demonstrated a scaling law or measured annotation savings unless the experiments establish those claims. Keep caveats in the corresponding weakness rather than canceling the strength inside this paragraph.

## 5. Weakness: identify the evidence gap and its consequence

Less suitable:

> The paper should add more evaluators, better rubrics, screening statistics, and more validation. The human grounding is not strong enough.

Preferred for a hypothetical benchmark with those reported limitations:

> The benchmark's diagnostic conclusions rely on elicited behaviours whose realization is insufficiently documented. Instructions and practice do not establish how consistently the intended behaviours occurred, and variation in their frequency or intensity could affect the comparisons between disruption types. The limited independent-rating audit also leaves reproducibility across listeners uncertain. Together, these gaps weaken the evidence for using the benchmark as a human-grounded reference.

The requests belong in Questions for Authors. The weakness itself explains the issue, evidence, and consequence. Do not use the paragraph if the manuscript already provides the relevant screening or reliability evidence.

## 6. Moderate a claim without obscuring it

Too broad:

> The core methodological contribution remains unclear because the experiments do not explain the design choices.

More precise:

> The experiments do not sufficiently isolate the contributions of the training objectives and benchmark-specific calibration. The reported ablations change the final score while keeping the predictor fixed, leaving the source of the gains uncertain.

Add verified section or table references directly. “Uncertain” here qualifies a specific attribution; it is not a defensive claim about the reviewer's personal understanding.

Avoid the opposite overcorrection:

> I cannot determine whether any part of the method is valid, and I suggest more experiments.

That sentence broadens the criticism while making its basis less clear.

## 7. Author question: one assessment purpose, no experiment inventory

Overloaded:

> Could the authors test different losses, temporal windows, bin counts, architectures, readouts, normalization statistics, and fusion weights, and also remove the development set?

Preferred when the purpose is component attribution:

> How much do the training objectives and target-dev calibration each contribute to test performance under retraining and calibration ablations?

If the existing score ablations need to be distinguished, add “rather than score-component removal alone.” Keep the detailed control protocol in the working discussion unless it is necessary to make the question answerable.

For a clarification request instead:

> What criterion selected the fusion weights, and which labels were available during selection?

The first asks for additional evidence; the second asks how the reported work was performed.

## 8. Initial reading notes versus polished review prose

Instruction to an assistant, not a reading note:

> Check whether the paper reports the active losses and determine whether this is an unresolved methodological concern or a presentation issue.

Reading-note style:

> Which losses are active at each stage? The appendix lists weights, but the training sequence is difficult to reconstruct. A stage-by-stage table would help.

Formal review style:

> The stage-specific objectives and trainable modules are not clearly specified, making the training procedure difficult to reconstruct.

Choose the appropriate product. A style rewrite is not a verbatim original note and must not be documented as one.

## 9. Statistical wording: name the scope

Too broad:

> The method significantly outperforms all baselines, but its low correlation is a statistical flaw.

Preferred, when supported:

> The method improves on the evaluated baselines, with statistically significant gains on some comparisons. The overall correlation remains modest, leaving the practical reliability of the score less well established than its comparative improvement.

Use “some comparisons” only after checking which comparisons are significant. A moderate correlation can limit practical usefulness without proving an error in the statistical procedure.

## 10. Shortening without losing the point

Verbose:

> The comparison is important because it would provide a useful opportunity to understand the extent to which the different parts of the proposed learning framework contribute to the performance observed in the evaluation results.

Concise:

> This comparison would isolate how much the training objective contributes to test performance.

In a formal weakness, prefer stating the current gap and its consequence. In an author question, ask for the comparison directly. Do not repeatedly explain why a reasonable request is “useful.”

## 11. Presentation as a brief supporting point

> Section 4 does not clearly distinguish model training, score calibration, and final evaluation. Separating these stages and mapping them to the results would make the contribution easier to assess.

Attach this to the affected methodological point. Do not create a major weakness for each unclear figure or transition.

## Final style check

For each paragraph, ask: does the first sentence identify a real contribution or concern; is there concrete support; is the consequence clear; and can any repeated explanation be removed? Preserve the user's accepted substance and wording where possible. Natural reviewer prose comes from clear judgment and specific evidence, not from hiding assistance or imitating errors.
