# Review workbook template

Copy this template to the paper's working directory and fill only the relevant parts. An empty field means information has not been recorded, not that the paper omits it. This workbook is not submission prose.

## Materials and current scope

- Paper and version:
- Venue, year, and track:
- Supplied form and score definitions:
- Available and missing materials:
- Current task scope:
- Accepted sections to preserve:
- Current output artifact:
- Applicable AI/confidentiality policy source and check date:

## Original annotations and mappings

| Source ID | Page/section | Original text or original-record location | R ID | Merge/split destination |
|---|---|---|---|---|

Record comment-bearing annotations, highlight-only regions, issues after splitting, and extraction gaps separately. Preserve the originals independently of the analysis below.

## Actual user-input log

Retain inputs verbatim in their actual order. Sources may include the current message, accessible earlier messages, or supplied attachments. Identify each attachment and its associated turn when known. State missing history explicitly. Do not invent timestamps or claim completeness without verification.

Each entry contains: sequence / actual timestamp if available / source / unedited full text / attachment references. Store AI-edited versions separately rather than inserting them as user inputs.

## Issue verification

| R ID | User's concern | Section/equation/table | Supporting and opposing evidence | Judgment and unknowns | Affected claim | Disposition |
|---|---|---|---|---|---|---|

Where needed, add the strongest author response, smallest decisive analysis, source annotation, and proposed English wording. Keep RESOLVED and NOT SUPPORTED items here, not in the unresolved author-facing list.

## Methods and results, when relevant

| Source/split | Role | Labels or supervision | Settings selected | Manuscript location | Unknowns |
|---|---|---|---|---|---|

| Main comparison | Split/unit | Metric and direction | Baseline and method results | Uncertainty | Supported and unsupported conclusions |
|---|---|---|---|---|---|

## Consolidation

| Working issue | Summary / Strength / Weakness / Author question / Resolved | Main argument | Current wording |
|---|---|---|---|

## Final checks

- Required factual or consistency corrections:
- Claims requiring a narrower scope:
- Optional wording improvements:
- Scores mapped to actual definitions, if requested:
- Coverage of the actual AI-input record:
- Export format and checks actually performed:
